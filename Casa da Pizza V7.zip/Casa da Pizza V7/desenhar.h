#ifndef DESENHAR_H_INCLUDED
#define DESENHAR_H_INCLUDED
#include "funcoes.h"
void desenhar(){

	gotoxy(0,0);
    pontaesquerdaCima(1);

    gotoxy(1,0);
    linha(78);

    gotoxy(79,0);
    pontadireitaCima(1);

    gotoxy(0, 1);
    colunaEsquerda(20);

    gotoxy(0,4);
    pontaesquerdaMeio(1);

    gotoxy(1,4);
    linha(78);

    gotoxy(79,4);
    pontadireitaMeio(1);

    int colunaDireitaRepetir;
    int x;
    for(x=1;x<4;x++) {
    gotoxy(79,x);
    colunaDireita(1);
    }

    for(x=5;x<21;x++) {
    gotoxy(79,x);
    colunaDireita(1);
    }

    gotoxy(0,21);
    pontaesquerdaBaixo(1);

    gotoxy(1,21);
    linha(78);

    gotoxy(79,21);
    pontadireitaBaixo(1);

	gotoxy(33, 20);
	printf("Data: "); system( "date /t" );


}



#endif // DESENHAR_H_INCLUDED
