#ifndef POSICIONAR_H_INCLUDED
#define POSICIONAR_H_INCLUDED
void gotoxy(int x, int y)
{
    //printf("%c[%d;%df",0x1B,y,x);
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}



#endif // POSICIONAR_H_INCLUDED
