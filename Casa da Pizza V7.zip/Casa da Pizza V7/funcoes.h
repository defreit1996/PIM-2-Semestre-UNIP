#ifndef FUNCOES_H_INCLUDED
#define FUNCOES_H_INCLUDED

//Desenhar Mascara
int mascaraLinha(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("_");
    }
    return qtd;
}

//Desenhar Tela
int pontaesquerdaCima(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 201);
    }
    return qtd;
}

int pontadireitaCima(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 187);
    }
    return qtd;
}

int linha(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 205);
    }
    return qtd;
}

int colunaEsquerda(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c\n", 186);
    }
    return qtd;
}

int colunaDireita(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c\n", 186);
    }
    return qtd;
}

int pontaesquerdaMeio(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 204);
    }
    return qtd;
}

int pontadireitaMeio(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 185);
    }
    return qtd;
}

int pontaesquerdaBaixo(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 200);
    }
    return qtd;
}

int pontadireitaBaixo(int qtd) {
    int x;
    for(x=0;x<qtd;x++) {
        printf("%c", 188);
    }
    return qtd;
}


#endif // FUNCOES_H_INCLUDED
