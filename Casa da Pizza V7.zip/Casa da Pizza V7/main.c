#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <windows.h>
#include <string.h>
#include "posicionar.h"
#include "colorir.h"
#include "desenhar.h"
#include "limpatela.h"
#include "sabores.h"
#include "Bebidas.h"
#include "TelaPrincipal.h"
#include "Funcionarios.h"
#include "Clientes.h"
#include "EstoqueMateriaP.h"
#include "Pedidos.h"
#include "SugestoesReclamacoes.h"
#include "Usuarios.h"

int main()
{
    bool sair = false, principal = true;
    int V_tentativas = 0;
    bool logado = false; //Inicialmente come�a como false pois o usuario n�o est� logado
    char nome_arquivo[] = "usuarios.txt"; //Arquivo que contem o usuario e senha
    char usuariotxt[20], senhatxt[20], usuario_digitado[20], senha_digitada[20], nome[20];

    gotoxy(0,0);
    pintar(121);
    limpaTela();

    //Enquanto a vari�vel logado for false, ele vai ter que digitar a senha
        gotoxy(20, 17);
        printf("Muita atencao voce tem apenas 3 tentavivas,");
        gotoxy(20,18);
        printf("apos as 3 tentativas o programa sera fechado.");

while(principal == true)//Valida o sistema Principal.
{
    while(logado == false) //Valida o Login.
    {
        char *ponteiro = "CASA DA PIZZA - LOGIN"; //Centralizar Titulo da Pagina
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);

        gotoxy(coluna, 2);
        printf("%s", ponteiro);// Printar Titulo
        desenhar();// DESENHA QUADRO PADRÃO
        gotoxy(20,9);
        printf("Login: ");
        gotoxy(20,11);
        printf("Senha: ");
        gotoxy(27,9);
        scanf("%s", usuario_digitado);
        gotoxy(27,11);
        scanf("%s", senha_digitada);
        FILE *arquivo;
        arquivo = fopen(nome_arquivo, "r+");

    while((fscanf(arquivo, "%s %s %s", usuariotxt, senhatxt, nome)) != EOF)
    {
        if (strcmp(usuario_digitado, usuariotxt)== 0)
        {
            if (strcmp(senha_digitada, senhatxt)== 0)
            {
                limpaTela();
                //printf("\nBem-vindo %s", nome);
                logado = true;
            }
        }
    }
    if (logado == false)
    {
        limpaTela();
        gotoxy(20, 16);
        printf("Usuario e/ou Senha Invalido(s).");
        limpaTela();
        V_tentativas ++;
    }
        if(V_tentativas == 1)
        {
                limpaTela();
                gotoxy(20, 18);
                printf("Atencao restam 2 tentativas.");
            }
            else if(V_tentativas == 2)
            {
                    limpaTela();
                    gotoxy(20, 18);
                    printf("Atencao resta 1 tentativa.");
                }
                else if(V_tentativas == 3)
                {
                        limpaTela();
                        logado = true;
                        sair = true;
                        principal = false;
                }
    fclose(arquivo);
    }
    limpaTela();

while(sair==false && logado == true) //Valida o Menu Principal
{
	int S_principal,S_Cadastro;
	bool V_M_cadastro = true;
        limpaTela();
        //Enquanto a variavel sair for false, o usuario tera acesso ao menu
        TelaPrincipal();
        gotoxy(36,15);
        scanf("%d", &S_principal);
        limpaTela();

	switch(S_principal)
	{
			case 1 : //Cadastro
                    do{
                        limpaTela();
                        char *ponteiro = "CADASTRO";
                        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
                        gotoxy(coluna, 2);
                        printf("%s", ponteiro);
                        desenhar();// DESENHAR DESGRAÇA
                        gotoxy(4, 8);
                        printf("1. Bebidas");
                        gotoxy(4, 9);
                        printf("2. Sabores");
                        gotoxy(4, 10);
                        printf("3. Funcionarios");
                        gotoxy(4, 11);
                        printf("4. Clientes");
                        gotoxy(4, 12);
                        printf("5. Estoque de Materia Prima");
                        gotoxy(4, 13);
                        printf("6. Usuarios");
                        gotoxy(4, 14);
                        printf("0. Voltar");
                        gotoxy(4, 16);
                        printf("Selecione uma das opcoes acima: ");
                        gotoxy(36, 16);
                        scanf("%d", &S_Cadastro);
                        limpaTela();

                        switch(S_Cadastro)
                        {
                            case 1:
                                limpaTela();
                                bebida();
                                break;
                            case 2 :
                                limpaTela();
                                sabores();
                                break;
                            case 3 :
                                funcionarios();
                                break;
                            case 4 :
                                limpaTela();
                                clientes();
                                break;
                            case 5 :
                                limpaTela();
                                estoque();
                                break;
                            case 6 :
                                limpaTela();
                                usuarios();
                                break;
                            case 0 :
                                V_M_cadastro = false;
                                break;
                            default:
                                limpaTela();
                                desenhar();// DESENHAR DESGRAÇA
                                gotoxy(4,8);
                                printf("Opcao Invalida.");
                                gotoxy(4,10);
                                system("Pause");
                            break;
                        }
                    }
                    while(V_M_cadastro == true);
                    break;

			case 2 :
				Pedidos();
				break;

            case 3 :
                S_Reclamacoes();
                break;
            case 4 :
                //A funçao desloga automaticamente e chama
                logado = false;
                //logado = logar();
                break;
            case 5 :
                sair = true;
                principal = false;
                break;
            default:
                limpaTela();
                desenhar();// DESENHA QUADRO PADRÃO
                gotoxy(4,8);
                printf("Opcao Invalida.");
                gotoxy(4,10);
                system("Pause");
            break;
            limpaTela();
            }
        }

    }
    return 0;
}
