#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void E_ler();
void E_adicionar();
void E_gravar();

typedef struct estoque
{
    char E_nome[15];
    char E_quantidade[15];
    char E_preco[15];
    struct Estoque *proximo;
}
Estoque;

Estoque *E_inicio = NULL;

char *E_arquivo = "Estoque.bin";

void estoque()
{
    bool E_validarMenu = true;
    int E_selecao;

    do {
        limpaTela();
        char *ponteiro = "CADASTRO - MATERIA PRIMA";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHAR
        gotoxy(4,8);
        printf("1. Adicionar Materia Prima");
        gotoxy(4,9);
        printf("0. Voltar");
        gotoxy(4,12);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,12);
        scanf("%d", &E_selecao);

            switch(E_selecao)
            {
                case 1:
                    limpaTela();
                    desenhar();// DESENHAR
                    E_ler();
                    E_adicionar();
                    E_gravar();
                    break;

                case 0:
                    E_validarMenu = false;
                break;

                default:
                    limpaTela();
                    desenhar();// DESENHAR
                    gotoxy(4,8);
                    printf("Opcao Invalida.");
                    gotoxy(4,10);
                    system("Pause");
                break;
            }
        }
        while(E_validarMenu == true);
}
void E_ler()
{
    Estoque *estoque;
    FILE *arq = fopen(E_arquivo,"r+b");

    while (!feof(arq))
    {
        estoque = (Estoque*) malloc(sizeof(Estoque));
        int qtd = fread(estoque,sizeof(Estoque),1,arq);
        if(qtd > 0)
        {
            if(E_inicio == NULL)
            {
                E_inicio = estoque;
                estoque->proximo = NULL;
            }
            else
            {
                Estoque *aux = E_inicio;
                estoque->proximo = aux;
                E_inicio = estoque;
            }
        }
    }
    fclose(arq);
}
void E_gravar()
{
    if(E_inicio != NULL)
    {
    Estoque *aux = E_inicio;
    FILE *arq = fopen(E_arquivo,"wb");
    while (aux != NULL)
    {
        fwrite(aux,sizeof(Estoque),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void E_adicionar()
{
    Estoque *novo = (Estoque*) malloc(sizeof(Estoque));
    int E_confirmacao;
    //Printa Titulo da Tela
    char *E_A_ponteiro = "ADICIONAR - MATERIA PRIMA";
    int E_coluna = ((80/2) - (strlen(E_A_ponteiro)) / 2);
    gotoxy(E_coluna, 2);
    printf("%s", E_A_ponteiro);
    gotoxy(4,8);
    printf("Nome do item:");
    gotoxy(4,9);
    printf("Preco unitario:");
    gotoxy(4,10);
    printf("Quantidade:");
    gotoxy(4,14);
    printf("Confirmar informacoes?");
    gotoxy(4,15);
    printf("1. SIM");
    gotoxy(4,16);
    printf("2. NAO");
    gotoxy(4,17);
    printf("->");
    getchar();
    gotoxy(18,8);
    fgets(novo->E_nome, sizeof(novo->E_nome), stdin);
    strtok(novo->E_nome, "\n");
    gotoxy(20,9);
    fgets(novo->E_preco, sizeof(novo->E_preco), stdin);
    strtok(novo->E_preco, "\n");
    gotoxy(16,10);
    fgets(novo->E_quantidade, sizeof(novo->E_quantidade), stdin);
    strtok(novo->E_quantidade, "\n");
    gotoxy(7,17);
    scanf("%d", &E_confirmacao);

    if(E_confirmacao == 1)
    {
        if(E_inicio == NULL)
        {
            E_inicio = novo;
            E_inicio->proximo = NULL;
        }
        else
        {
            Estoque *aux = E_inicio;
            E_inicio = novo;
            E_inicio->proximo = aux;
        }
    }
    else
    {
        free(novo);
    }
}
