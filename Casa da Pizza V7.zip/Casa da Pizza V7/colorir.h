#ifndef COLORIR_H_INCLUDED
#define COLORIR_H_INCLUDED

void pintar(int cor){
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hStdOut, cor);
}


#endif // COLORIR_H_INCLUDED
