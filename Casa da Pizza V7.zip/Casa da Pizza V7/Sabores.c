#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void S_ler();
void S_adicionar();
void S_gravar();

typedef struct sabor
{
    char S_nome [15];
    char S_preco [15];
    struct Sabor *proximo;
}
Sabor;

Sabor *S_inicio = NULL;

char *S_arquivo = "sabores.bin";

void sabores()
{
    //Declarando Variaveis
    bool S_validarSubMenu = true;
    bool S_validarMenu = true;
    int S_selecao;
    do{//Repete tudo do DO de acordo a a verificacao do WHILE
        limpaTela();
        char *S_titulo = "CADASTRO - SABORES";
        int S_coluna = ((80/2) - (strlen(S_titulo)) / 2);
        gotoxy(S_coluna, 2);
        printf("%s", S_titulo);
        desenhar();// DESENHA QUADRO PADR�O
        gotoxy(4,8);
        printf("1. Adicionar Sabores");
        gotoxy(4,9);
        printf("0. Voltar");
        gotoxy(4,12);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,12);
        scanf("%d", &S_selecao);

    switch(S_selecao)
    {
        case 1:// Adicionar Sabores
                limpaTela();
                desenhar();
                S_ler();
                S_adicionar();
                S_gravar();
                break;
        case 0:// Voltar
                S_validarMenu = false;
                break;
        default:// Op�ao Invalida
                limpaTela();
                desenhar();
                gotoxy(4,10);
                printf("Opcao Invalida");
                gotoxy(4,12);
                break;
    	}
    }
    while(S_validarMenu == true);
}
void S_ler()
{
    Sabor *sabor;
    FILE *arq = fopen(S_arquivo,"r+b");

    while (!feof(arq))
    {
        sabor = (Sabor*) malloc(sizeof(Sabor));
        int qtd = fread(sabor,sizeof(Sabor),1,arq);
        if(qtd > 0){
            if(S_inicio == NULL)
            {
                S_inicio = sabor;
                sabor->proximo = NULL;
            }
            else
            {
                Sabor *aux = S_inicio;
                sabor->proximo = aux;
                S_inicio = sabor;
            }
        }
    }
    fclose(arq);
}
void S_gravar()
{

    if(S_inicio != NULL)
    {
    Sabor *aux = S_inicio;
    FILE *arq = fopen(S_arquivo,"wb");

    while (aux != NULL)
    {
        fwrite(aux,sizeof(Sabor),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void S_adicionar()
{
    Sabor *novo = (Sabor*) malloc(sizeof(Sabor));
    int S_confirmacao;
    //Printa Titulo da Tela
    char *S_A_ponteiro = "ADICIONAR - SABORES";
    int coluna = ((80/2) - (strlen(S_A_ponteiro)) / 2);
    gotoxy(coluna, 2);
    printf("%s", S_A_ponteiro);

    gotoxy(4,8);
    printf("Sabor:");
    gotoxy(4,10);
    printf("Preco:");
    gotoxy(4,14);
    printf("Confirmar informacoes?");
    gotoxy(4,15);
    printf("1. SIM");
    gotoxy(4,16);
    printf("2. NAO");
    gotoxy(4,17);
    printf("->");
    getchar();
    gotoxy(11,8);
    fgets(novo->S_nome, sizeof(novo->S_nome), stdin);
    strtok(novo->S_nome, "\n");
    gotoxy(11,10);
    fgets(novo->S_preco, sizeof(novo->S_preco), stdin);
    strtok(novo->S_preco, "\n");
    gotoxy(7,17);
    scanf("%d", &S_confirmacao);

    if(S_confirmacao == 1)
    {
        if(S_inicio == NULL)
        {
            S_inicio = novo;
            S_inicio->proximo = NULL;
        }
        else
        {
            Sabor *aux = S_inicio;
            S_inicio = novo;
            S_inicio->proximo = aux;
        }
    }
    else
    {
        free(novo);
    }
}
