#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void U_adicionar();
void U_ler();
void U_gravar();

typedef struct usuario{
    char U_login[15];
	char U_senha[15];
	char U_nome[15];
 	struct usuario *proximo;
}Usuario;

Usuario *U_inicio = NULL;

char *U_arquivo = "usuarios.txt";

void usuarios(){
    //Declarando Variaveis
	int S_usuario;
	bool V_usuario = true;
	do{// Repete tudo do DO referente a verivicacao do While
            U_ler();
            limpaTela();
            char *ponteiro = "CADASTRO - USUARIOS";
            int coluna = ((80/2) - (strlen(ponteiro)) / 2);
            gotoxy(coluna, 2);
            printf("%s", ponteiro);
            desenhar();// DESENHAR
            gotoxy(4,8);
            printf("1. Adicionar Usuario");
            gotoxy(4,9);
            printf("0. Voltar");
            gotoxy(4,12);
            printf("Selecione uma das opcoes acima: ");
            gotoxy(36,12);
            scanf("%d", &S_usuario);

	switch(S_usuario){
		case 1://Adicionar Usuario
                U_ler();
                U_adicionar();
			break;
		case 0://Voltar
			V_usuario = false;
			break;
		default://Opcao Invalida
                limpaTela();
                desenhar();// DESENHA QUADRO RPINCIPAL
                gotoxy(4,8);
                printf("Opcao Invalida.");
                gotoxy(4,10);
			break;
	}
	}while(V_usuario == true);
}
void U_ler(){
    Usuario *usuario;
    FILE *arq = fopen(U_arquivo,"r");

    while (!feof(arq))
    {   usuario  = (Usuario*) malloc(sizeof(Usuario));
        int qtd = fread(usuario,sizeof(Usuario),1,arq);
        if(qtd > 0){
            if(U_inicio == NULL){
                U_inicio = usuario;
                usuario->proximo = NULL;
            }
            else{
                Usuario *aux = U_inicio;
                usuario->proximo = aux;
                U_inicio = usuario;
            }
        }
    }
    fclose(arq);
}
void U_adicionar(){
        Usuario *novo  = (Usuario*) malloc(sizeof(Usuario));
        int U_confirmacao;
        limpaTela();
        char *ponteiro = "ADICIONAR - USUARIOS";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHA QUADRO PADRAO
        gotoxy(4,8);
        printf("Login:");
        gotoxy(4,9);
        printf("Senha:");
        gotoxy(4,10);
        printf("Nome do Usuario:");
        gotoxy(4,14);
        printf("Confirmar informacoes?");
        gotoxy(4,15);
        printf("1. SIM");
        gotoxy(4,16);
        printf("2. NAO");
        gotoxy(4,17);
        printf("->");
        getchar();
        gotoxy(11,8);
        fgets(novo->U_login, sizeof(novo->U_login),stdin);
        strtok(novo->U_login, "\n");
        gotoxy(12,9);
        fgets(novo->U_senha, sizeof(novo->U_senha), stdin);
        strtok(novo->U_senha, "\n");
        gotoxy(21,10);
        fgets(novo->U_nome, sizeof(novo->U_nome), stdin);
        strtok(novo->U_nome, "\n");
        gotoxy(7,17);
        scanf("%d", &U_confirmacao);

            if(U_confirmacao == 1)
            {
                if(U_inicio == NULL)
                {
                    U_inicio = novo;
                    U_inicio->proximo = NULL;
                }
                else
                {
                    Usuario *aux = U_inicio;
                    U_inicio = novo;
                    U_inicio->proximo = aux;
                }
                    U_gravar();
            }
            else
            {
            free(novo);
            }
        limpaTela();
}
void U_gravar()
{
    if(U_inicio != NULL){
    Usuario *aux = U_inicio;
    FILE *arq = fopen(U_arquivo,"a+");

    fprintf(arq,"%s %s %s \n",aux->U_login, aux->U_senha, aux->U_nome );
    aux = aux->proximo;

    fclose(arq);
    }
}
