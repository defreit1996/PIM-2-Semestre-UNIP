#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void B_ler();
void B_adicionar();
void B_gravar();

typedef struct bebida
{
    char B_nome[21];
    char B_quantidade[23];
    char B_classificacao[22];
    char B_preco[23];
    struct bebida *proximo;
}
Bebida;

Bebida *B_inicio = NULL;

char *B_arquivo = "bebidas.bin";

void bebida()
{
    int B_selecao;
    bool B_validarMenu = true;
    int B_retirarbebida;
    bool B_validarRetirada = true;

    do {

        limpaTela();
        char *ponteiro = "CADASTRO - BEBIDAS";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHAR
        gotoxy(4,9);
        printf("1. Adicionar Bebidas");
        gotoxy(4,10);
        printf("0. Voltar");
        gotoxy(4,14);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36, 14);
        scanf("%d", &B_selecao);

        switch(B_selecao)
        {
            case 1:
                limpaTela();
                char *B_titulo = "ADICIONAR - BEBIDAS";
                int B_coluna = ((80/2) - (strlen(B_titulo)) / 2);
                gotoxy(B_coluna, 2);
                printf("%s", B_titulo);
                desenhar();// DESENHAR
                B_ler();
                B_adicionar();
                B_gravar();
            break;
            case 0:
                B_validarMenu = false;
            break;

            default:
                limpaTela();
                desenhar();// DESENHAR DESGRA�A
                gotoxy(4,8);
                printf("Opcao Invalida.");
                gotoxy(4,10);
                system("Pause");
                break;
        }
    }
    while (B_validarMenu == true);
}
void B_adicionar()
{
    Bebida *novo = (Bebida*) malloc(sizeof(Bebida));
    int B_confirmacao;
    gotoxy(4,8);
    printf("Nome da Bebida:");
    gotoxy(4,9);
    printf("Tipo de Bebida:");
    gotoxy(4, 10);
    printf("1. Alcoolica");
    gotoxy(4, 11);
    printf("2. Nao Alcoolica");
    gotoxy(4, 12);
    printf("->");
    gotoxy(4,13);
    printf("Quantidade de Bebidas: ");
    gotoxy(4,14);
    printf("Valor Unitario da Bebida: ");
    gotoxy(4,16);
    printf("Confirmar informacoes?");
    gotoxy(4,17);
    printf("1. SIM");
    gotoxy(4,18);
    printf("2. NAO");
    gotoxy(4,19);
    printf("->");
    getchar();
    gotoxy(20,8);
    fgets(novo->B_nome, sizeof(novo->B_nome), stdin);
    strtok(novo->B_nome, "\n");
    gotoxy(7,12);
    fgets(novo->B_classificacao, sizeof(novo->B_classificacao), stdin);
    strtok(novo->B_classificacao, "\n");
    gotoxy(27,13);
    fgets(novo->B_quantidade, sizeof(novo->B_quantidade), stdin);
    strtok(novo->B_quantidade, "\n");
    gotoxy(30,14);
    fgets(novo->B_preco, sizeof(novo->B_preco), stdin);
    strtok(novo->B_preco, "\n");
    gotoxy(8,19);
    scanf("%d", &B_confirmacao);

    if(B_confirmacao == 1)
    {
        if(B_inicio == NULL)
        {
            B_inicio = novo;
            B_inicio->proximo = NULL;
        }
        else
        {
            Bebida *aux = B_inicio;
            B_inicio = novo;
            B_inicio->proximo = aux;
        }
    }
    else
    {
        free(novo);
    }
}
void B_gravar()
{
    if(B_inicio != NULL)
    {
    Bebida *aux = B_inicio;
    FILE *arq = fopen(B_arquivo,"wb");

    while (aux != NULL)
    {
        //printf("\n-> %s, %s", aux->nome, aux->fone);
        fwrite(aux,sizeof(Bebida),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void B_ler()
{
    Bebida *bebida;
    FILE *arq = fopen(B_arquivo,"r+b");

    while (!feof(arq))
    {
        bebida  = (Bebida*) malloc(sizeof(Bebida));
        int qtd = fread(bebida,sizeof(Bebida),1,arq);
        if(qtd > 0){
            if(B_inicio == NULL)
            {
                B_inicio = bebida;
                bebida->proximo = NULL;
            }
            else
            {
                Bebida *aux = B_inicio;
                bebida->proximo = aux;
                B_inicio = bebida;
            }
        }
    }
    fclose(arq);
}
