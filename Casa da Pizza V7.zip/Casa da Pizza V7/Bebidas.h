#ifndef BEBIDAS_H_INCLUDED
#define BEBIDAS_H_INCLUDED

void bebidas();

#endif // BEBIDAS_H_INCLUDED
