#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void P_ler();
void P_adicionar();
void P_gravar();

typedef struct pedido
{
    char P_pizza [15];
    char P_bebida [15];
    int P_quantidadeP;
    int P_quantidadeB;
    char P_tamanho [15];
    struct Pedido *proximo;
}
Pedido;

Pedido *P_inicio = NULL;

char *P_arquivo = "Pedidos.bin";

void Pedidos(){
    //Declarando Variaveis
	int P_selecao;
	bool P_validarMenu = true;

	limpaTela();
        //Alinhar o Texto
        char *ponteiro = "PEDIDOS";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHAR
        gotoxy(4, 8);
        printf("1. Adicionar Pedido");
        gotoxy(4, 9);
        printf("0. Voltar");
        gotoxy(4, 12);
        printf("Selecione uma das opcoes acima:");
        //mascaraLinha(2);
        gotoxy(36, 12);
        scanf("%d", &P_selecao);

	switch(P_selecao){
		case 1: //Adicionar Pedidos
			do {
				limpaTela();
				char *ponteiroAP = "PEDIDOS - ADICIONAR";
                int colunaAP = ((80/2) - (strlen(ponteiroAP)) / 2);
                gotoxy(colunaAP, 2);
                printf("%s", ponteiroAP);
				desenhar();// DESENHAR
                P_ler();
                P_adicionar();
			break;
		case 0://Voltar
			P_validarMenu = false;
			break;
                default:
                        limpaTela();
                        desenhar();// DESENHA QUADRO PADR�O
                        gotoxy(4,8);
                        printf("Opcao Invalida.");
                        gotoxy(4,10);
                break;
            }while(P_validarMenu == true);
    }
}
void P_adicionar()
{
    Pedido *novo = (Pedido*) malloc(sizeof(Pedido));
    int P_confirmacao;
    gotoxy(4,7);
    printf("Sabor da Pizza:");
    gotoxy(4,8);
    printf("Tamanho:");
    gotoxy(4,9);
    printf("Quantidade:");
    gotoxy(4,16);
    printf("Confirmar informacoes?");
    gotoxy(4,17);
    printf("1. SIM");
    gotoxy(4,18);
    printf("2. NAO");
    gotoxy(4,19);
    printf("->");
    getchar();
    gotoxy(20,7);
    fgets(novo->P_pizza, sizeof(novo->P_pizza), stdin);
    strtok(novo->P_pizza, "\n");
    gotoxy(13,8);
    fgets(novo->P_tamanho, sizeof(novo->P_tamanho), stdin);
    strtok(novo->P_tamanho, "\n");
    gotoxy(16,9);
    scanf("%d", &novo->P_quantidadeP);
    gotoxy(8,19);
    scanf("%d", &P_confirmacao);

    if(P_confirmacao == 1)
    {
        if(P_inicio == NULL)
        {
            P_inicio = novo;
            P_inicio->proximo = NULL;
        }
        else
        {
            Pedido *aux = P_inicio;
            P_inicio = novo;
            P_inicio->proximo = aux;
        }
        P_gravar();
    }
    else
    {
        free(novo);
    }
}

void P_gravar()
{
    if(P_inicio != NULL)
    {
    Pedido *aux = P_inicio;
    FILE *arq = fopen(P_arquivo,"wb");

    while (aux != NULL)
    {
        fwrite(aux,sizeof(Pedido),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}

void P_ler()
{
    Pedido *pedido;
    FILE *arq = fopen(P_arquivo,"r+b");
    while (!feof(arq))
    {
        pedido  = (Pedido*) malloc(sizeof(Pedido));
        int qtd = fread(pedido,sizeof(Pedido),1,arq);
        if(qtd > 0)
        {
            if(P_inicio == NULL)
            {
                P_inicio = pedido;
                pedido->proximo = NULL;
            }
            else
            {
                Pedido *aux = P_inicio;
                pedido->proximo = aux;
                P_inicio = pedido;
            }
        }
    }
    fclose(arq);
}

