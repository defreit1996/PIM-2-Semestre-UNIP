#ifndef RELATORIOS_H_INCLUDED
#define RELATORIOS_H_INCLUDED

void Relatorios() {
    //Declarando Varivaveis
    int S_relatorios;
    bool V_M_relatorios = true;

    do {// Repete tudo do DO diante a verificacao do While
        limpaTela();
        char *ponteiro = "RELATORIOS";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHA QUADRO PADRÃO
        gotoxy(4,7);
        printf("1. Bebidas");
        gotoxy(4,8);
        printf("2. Sabores");
        gotoxy(4,9);
        printf("3. Funcionarios");
        gotoxy(4,10);
        printf("4. Clientes");
        gotoxy(4,11);
        printf("5. Estoque de Materia Prima");
        gotoxy(4,12);
        printf("6. Pedidos");
        gotoxy(4,13);
        printf("7. Receita");
        gotoxy(4,14);
        printf("8. Sugestoes/Reclamacoes");
        gotoxy(4,15);
        printf("0. Voltar");
        gotoxy(4,17);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,17);
        scanf("%d", &S_relatorios);

    switch(S_relatorios) {
        case 1:
            limpaTela();
            printf("Relatorio de Bebidas");
        break;
        case 2:
            limpaTela();
            printf("Relatorio de Sabores");
        break;
        case 3:
            limpaTela();
            printf("Relatorio de Funcionarios");
        break;
        case 4:
            limpaTela();
            printf("Relatorio de Clientes");
        break;
        case 5:
            limpaTela();
            printf("Relatorio de Estoque de Materia Prima");
        break;
        case 6:
            limpaTela();
            printf("Relatorio de Pedidos");
        break;
        case 7:
            limpaTela();
            printf("Relatorio de Receita");
        break;
        case 8:
            limpaTela();
            printf("Relatorio de Sugestoes/Reclamacoes");
        break;
        case 0:// Voltar
            limpaTela();
            printf("Voltar");
            V_M_relatorios = false;
        break;
        default:// Opcao Invalida
            limpaTela();
            desenhar();// DESENHA QUADRO PADRÃO
            gotoxy(4,8);
            printf("Opcao Invalida.");
            gotoxy(4,10);
            system("Pause");
        break;
    }
}while (V_M_relatorios == true);

}


#endif // RELATORIOS_H_INCLUDED
