#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void F_ler();
void F_adicionar();
void F_gravar();

typedef struct funcionario
{
    char F_nome[15];
    char F_cargo[15];
    char F_salario[15];
    struct funcionario *proximo;
}
Funcionario;

Funcionario *F_inicio = NULL;

char *F_arquivo = "funcionarios.bin";

void funcionarios()
{
//Declarando Variaveis
    int F_selecao;
    bool F_validaocao = true;

    do{ //Repete tudo do DO de acordo com a verificacao do WHILE
        limpaTela();
        char *ponteiro = "CADASTRO - FUNCIONARIOS";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();//DESENHA Quadro Padrao

        gotoxy(4,9);
        printf("1. Adicionar Funcionarios");
        gotoxy(4,10);
        printf("0. Voltar");
        gotoxy(4,13);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,13);
        scanf("%d", &F_selecao);

    switch(F_selecao)
    {

        case 0:// Voltar
                F_validaocao = false;
                break;
        case 1:// Adiconar Funcionario
            limpaTela();
            char *F_titulo = "ADICIONAR FUNCIONARIOS";
            int F_coluna = ((80/2) - (strlen(F_titulo)) / 2);
            gotoxy(F_coluna, 2);
            printf("%s", F_titulo);
            desenhar();//DESENHA QUADRO PRINCIPAL
            F_ler();
            F_adicionar();
            F_gravar();
            break;
        default://Opcao Invalida
            limpaTela();
            desenhar();// DESENHAR QUARDO PADRAO
            gotoxy(4,8);
            printf("Opcao Invalida.");
            break;
        }
    }
    while(F_validaocao == true);
}
void F_ler()
{
    Funcionario *funcionario;
    FILE *arq = fopen(F_arquivo,"r+b");

    while (!feof(arq))
    {
        funcionario = (Funcionario*) malloc(sizeof(Funcionario));
        int qtd = fread(funcionario,sizeof(Funcionario),1,arq);
        if(qtd > 0){
            if(F_inicio == NULL){
                F_inicio = funcionario;
                funcionario->proximo = NULL;
            }
            else
            {
                Funcionario *aux = F_inicio;
                funcionario->proximo = aux;
                F_inicio = funcionario;
            }
        }
    }
    fclose(arq);
}
void F_gravar()
{
    if(F_inicio != NULL)
    {
    Funcionario *aux = F_inicio;
    FILE *arq = fopen(F_arquivo,"wb");

    while (aux != NULL)
    {
        fwrite(aux,sizeof(Funcionario),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void F_adicionar()
{
    Funcionario *novo = (Funcionario*) malloc(sizeof(Funcionario));
    int F_confirmacao;
    //Printa Titulo da Tela
    char *F_A_ponteiro = "ADICIONAR - FUNCIONARIOS";
    int F_coluna = ((80/2) - (strlen(F_A_ponteiro)) / 2);
    gotoxy(F_coluna, 2);
    printf("%s", F_A_ponteiro);

    gotoxy(4,8);
    printf("Nome:");
    gotoxy(4,9);
    printf("Cargo:");
    gotoxy(4,10);
    printf("Salario:");
    gotoxy(4,14);
    printf("Confirmar informacoes?");
    gotoxy(4,15);
    printf("1. SIM");
    gotoxy(4,16);
    printf("2. NAO");
    gotoxy(4,17);
    printf("->");
    getchar();
    gotoxy(11,8);
    fgets(novo->F_nome, sizeof(novo->F_nome), stdin);
    strtok(novo->F_nome, "\n");
    gotoxy(12,9);
    fgets(novo->F_cargo, sizeof(novo->F_cargo), stdin);
    strtok(novo->F_cargo, "\n");
    gotoxy(14,10);
    fgets(novo->F_salario, sizeof(novo->F_salario), stdin);
    strtok(novo->F_salario, "\n");
    gotoxy(7,17);
    scanf("%d", &F_confirmacao);

    if(F_confirmacao == 1)
    {
        if(F_inicio == NULL)
        {
            F_inicio = novo;
            F_inicio->proximo = NULL;
        }
        else
        {
            Funcionario *aux = F_inicio;
            F_inicio = novo;
            F_inicio->proximo = aux;
        }
    }
    else
    {
        free(novo);
    }
}
