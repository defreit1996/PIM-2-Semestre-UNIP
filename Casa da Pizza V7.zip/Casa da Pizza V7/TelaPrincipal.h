#ifndef TELAPRINCIPAL_H_INCLUDED
#define TELAPRINCIPAL_H_INCLUDED
void TelaPrincipal(){
    char *ponteiro = "MENU PRINCIPAL";
    int coluna = ((80/2) - (strlen(ponteiro)) / 2);
    gotoxy(coluna, 2);
    printf("%s", ponteiro);

    desenhar();// DESENHA QUADRO PADRÃO
    gotoxy(4,8);
    printf("1. Cadastro");
    gotoxy(4,9);
    printf("2. Pedidos");
    gotoxy(4,10);
    printf("3. Sugestoes/Reclamacoes");
    gotoxy(4,11);
    printf("4. Deslogar");
    gotoxy(4,12);
    printf("5. Sair do Sistema");
    gotoxy(4,15);
    printf("Selecione uma das opcoes acima: ");
}
#endif // TELAPRINCIPAL_H_INCLUDED
