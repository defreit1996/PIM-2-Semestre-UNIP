#ifndef LIMPATELA_H_INCLUDED
#define LIMPATELA_H_INCLUDED

int limpaTela(){
    //return system("clear");
    return system("cls");
}

#endif // LIMPATELA_H_INCLUDED
