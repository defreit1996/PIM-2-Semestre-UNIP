#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void C_ler();
void C_adicionar();
void C_gravar();

typedef struct cliente
{
    char C_nome[21];
    char C_email[23];
    char C_telefone[22];
    struct Cliente *proximo;
}
Cliente;

Cliente *C_inicio = NULL;

char *C_arquivo = "Clientes.bin";

void clientes()
{
    //Declarando Variaveis
    bool C_validaMenu = true;
    int C_selecao,V_C_A_sobares;

    do {//Repete tudo do DO de acordo com a verificacao do WHILE
        limpaTela();
        char *ponteiro = "CADASTRO - CLIENTES";
        int coluna = ((80/2) - (strlen(ponteiro)) / 2);
        gotoxy(coluna, 2);
        printf("%s", ponteiro);
        desenhar();// DESENHAR
        gotoxy(4,8);
        printf("1. Adicionar Clientes");
        gotoxy(4,9);
        printf("0. Voltar");
        gotoxy(4,12);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,12);
        scanf("%d", &C_selecao);

        switch(C_selecao)
        {
            case 1://Adiciona Clientes
                limpaTela();
                char *C_tituloAdicionar = "ADICIONAR - CLIENTES";
                int coluna = ((80/2) - (strlen(C_tituloAdicionar)) / 2);
                gotoxy(coluna, 2);
                printf("%s", C_tituloAdicionar);
                desenhar();// DESENHAR
                C_ler();
                C_adicionar();
                C_gravar();
            break;
            case 0:
                C_validaMenu = false;
            break;

                default:
                        limpaTela();
                        desenhar();// DESENHA QUADRO PADRÃO
                        gotoxy(4,8);
                        printf("Opcao Invalida.");
                        gotoxy(4,10);
                        system("Pause");
                break;
        }
    }
    while(C_validaMenu == true);
}
void C_ler()
{
    Cliente *cliente;
    FILE *arq = fopen(C_arquivo,"r+b");

    while (!feof(arq))
    {
        cliente = (Cliente*) malloc(sizeof(Cliente));
        int qtd = fread(cliente,sizeof(Cliente),1,arq);
        if(qtd > 0)
        {
            if(C_inicio == NULL)
            {
                C_inicio = cliente;
                cliente->proximo = NULL;
            }
            else
            {
                Cliente *aux = C_inicio;
                cliente->proximo = aux;
                C_inicio = cliente;
            }
        }
    }
    fclose(arq);
}
void C_gravar()
{
    if(C_inicio != NULL)
    {
    Cliente *aux = C_inicio;
    FILE *arq = fopen(C_arquivo,"wb");

    while (aux != NULL)
    {
        fwrite(aux,sizeof(Cliente),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void C_adicionar()
{
    Cliente *novo = (Cliente*) malloc(sizeof(Cliente));
    int C_confirmacao;
    gotoxy(4,8);
    printf("Nome Completo:");
    gotoxy(4,9);
    printf("Email:");
    gotoxy(4,10);
    printf("Telofone:");
    gotoxy(4,14);
    printf("Confirmar informacoes?");
    gotoxy(4,15);
    printf("1. SIM");
    gotoxy(4,16);
    printf("2. NAO");
    gotoxy(4,17);
    printf("->");
    getchar();
    gotoxy(20,8);
    fgets(novo->C_nome, sizeof(novo->C_nome), stdin);
    strtok(novo->C_nome, "\n");
    gotoxy(11,9);
    fgets(novo->C_email, sizeof(novo->C_email), stdin);
    strtok(novo->C_email, "\n");
    gotoxy(15,10);
    fgets(novo->C_telefone, sizeof(novo->C_telefone), stdin);
    strtok(novo->C_telefone, "\n");
    gotoxy(7,17);
    scanf("%d", &C_confirmacao);

    if(C_confirmacao == 1)
    {
        if(C_inicio == NULL)
        {
            C_inicio = novo;
            C_inicio->proximo = NULL;
        }
        else
        {
            Cliente *aux = C_inicio;
            C_inicio = novo;
            C_inicio->proximo = aux;
        }
    }
    else
    {
        free(novo);
    }
}
