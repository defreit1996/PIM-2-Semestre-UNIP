#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

void SR_ler();
void SRs_adicionar();
void SRr_adicionar();
void SR_gravar();

typedef struct sugestaoR
{
    char SR_texto[255];
    struct SugestaoR *proximo;
}
SugestaoR;

SugestaoR *SR_inicio = NULL;

char *SR_arquivo = "SugestaoReclamacao.bin";

void S_Reclamacoes()
{
    //Declrando Variaveis
    bool SR_validarMenu = true;
    int SR_selecao;
        do
        {
        limpaTela();
        char *SR_titulo = " CADASTRO - SUGESTAO / RECLAMACAO";
        int SR_coluna = ((80/2) - (strlen(SR_titulo)) / 2);
        gotoxy(SR_coluna, 2);
        printf("%s", SR_titulo);
        desenhar();// DESENHAR
        gotoxy(4,8);
        printf("1. Sugestao");
        gotoxy(4,9);
        printf("2. Reclamacao");
        gotoxy(4,10);
        printf("0. Voltar");
        gotoxy(4,12);
        printf("Selecione uma das opcoes acima: ");
        gotoxy(36,12);
        scanf("%d", &SR_selecao);

            switch(SR_selecao)
            {
                case 1:
                    limpaTela();
                    limpaTela();
                    char *S_titulo = "SUGESTAO";
                    int S_coluna = ((80/2) - (strlen(S_titulo)) / 2);
                    gotoxy(S_coluna, 2);
                    printf("%s", S_titulo);
                    desenhar();// DESENHAR
                    SR_ler();
                    SRs_adicionar();
                    break;

                case 2:
                    limpaTela();
                    char *R_titulo = "RECLAMACAO";
                    int R_coluna = ((80/2) - (strlen(R_titulo)) / 2);
                    gotoxy(R_coluna, 2);
                    printf("%s", R_titulo);
                    desenhar();// DESENHAR
                    SR_ler();
                    SRr_adicionar();
                    limpaTela();
                break;

                case 0:
                    SR_validarMenu = false;
                break;
                default:
                    limpaTela();
                    desenhar();// DESENHAR
                    gotoxy(4,8);
                    printf("Opcao Invalida.");
                    gotoxy(4,10);
                break;
            }

        }
        while(SR_validarMenu == true);
}
void SR_ler()
{
    SugestaoR *sugestaoR;
    FILE *arq = fopen(SR_arquivo,"r+b");

    while (!feof(arq))
    {
        sugestaoR = (SugestaoR*) malloc(sizeof(SugestaoR));
        int qtd = fread(sugestaoR,sizeof(SugestaoR),1,arq);
        if(qtd > 0)
        {
            if(SR_inicio == NULL)
            {
                SR_inicio = sugestaoR;
                sugestaoR->proximo = NULL;
            }
            else
            {
                SugestaoR *aux = SR_inicio;
                sugestaoR->proximo = aux;
                SR_inicio = sugestaoR;
            }
        }
    }
    fclose(arq);
}
void SR_gravar()
{
    if(SR_inicio != NULL)
    {
    SugestaoR *aux = SR_inicio;
    FILE *arq = fopen(SR_arquivo,"wb");

    while (aux != NULL)
    {
        fwrite(aux,sizeof(SugestaoR),1,arq);
        aux = aux->proximo;
    }
    fclose(arq);
    }
}
void SRs_adicionar()
{
    SugestaoR *novo = (SugestaoR*) malloc(sizeof(SugestaoR));
    int S_confirmacao;
        limpaTela();
        gotoxy(4,8);
        printf("Sugestao:");
        gotoxy(4,16);
        printf("Confirmar informacoes?");
        gotoxy(4,17);
        printf("1. SIM");
        gotoxy(4,18);
        printf("2. NAO");
        gotoxy(4,19);
        printf("->");
        getchar();
        gotoxy(14,8);
        fgets(novo->SR_texto, sizeof(novo->SR_texto), stdin);
        strtok(novo->SR_texto, "\n");
        gotoxy(7,19);
        scanf("%d", &S_confirmacao);

        if(S_confirmacao == 1)
        {
            if(SR_inicio == NULL)
            {
                SR_inicio = novo;
                SR_inicio->proximo = NULL;
            }
            else
            {
                SugestaoR *aux = SR_inicio;
                SR_inicio = novo;
                SR_inicio->proximo = aux;
            }
            SR_gravar();
        }
        else
        {
            free(novo);
        }
}
void SRr_adicionar()
{
    SugestaoR *novo = (SugestaoR*) malloc(sizeof(SugestaoR));
    int S_confirmacao;
        limpaTela();
        gotoxy(4,8);
        printf("Reclamacao:");
        gotoxy(4,16);
        printf("Confirmar informacoes?");
        gotoxy(4,17);
        printf("1. SIM");
        gotoxy(4,18);
        printf("2. NAO");
        gotoxy(4,19);
        printf("->");
        getchar();
        gotoxy(18,8);
        fgets(novo->SR_texto, sizeof(novo->SR_texto), stdin);
        strtok(novo->SR_texto, "\n");
        gotoxy(7,19);
        scanf("%d", &S_confirmacao);

        if(S_confirmacao == 1)
        {
            if(SR_inicio == NULL)
            {
                SR_inicio = novo;
                SR_inicio->proximo = NULL;
            }
            else
            {
                SugestaoR *aux = SR_inicio;
                SR_inicio = novo;
                SR_inicio->proximo = aux;
            }
        }
        else
        {
            free(novo);
        }
}
